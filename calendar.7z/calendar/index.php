 <?php
//  error_reporting(0);
$servername = "localhost";
$database = "calendar";
$username = "root";
$password = "";

// Соединение с БД
$conn = mysqli_connect($servername, $username, $password, $database);

?>

<!DOCTYPE html>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/style/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Source+Code+Pro:wght@300&display=swap" rel="stylesheet">
    <title>Calendar</title>
</head>
<body> 

    <form id="book-form" method="POST"action="">
        <div class="calendar" id="calendar">
            <!-- <div class="month">
                <div class="month__name">Январь <div class="line"></div></div>
                    <div class="content">
                       <div class="month__date dweek">пн</div> 
                       <div class="month__date dweek">вт</div>
                       <div class="month__date dweek">ср</div>
                       <div class="month__date dweek">чт</div>
                       <div class="month__date dweek">пт</div>
                       <div class="month__date dweek month__date__weeknd">сб</div>
                       <div class="month__date dweek month__date__weeknd">вс</div>
                       <div class="month__date day__number" id="id_1">1</div>
                       <div class="month__date day__number" id="id_2">2</div>
                       <div class="month__date day__number" id="id_3">3</div>
                       <div class="month__date day__number" id="id_4">4</div>
                       <div class="month__date day__number" id="id_5">5</div>
                       <div class="month__date day__number" id="id_6">6</div>
                       <div class="month__date day__number" id="id_7">7</div>
                    </div>
            </div> -->
        </div>
        <div class="phoneField">        
               <div class="title">
                    <label for="phone">Укажите телефон:</label>
                    <input name="phone" type="tel" id="phone" class="phone" required pattern="[0-9]{11}" placeholder="+7 (___) ___-__-__" />
                </div>
                <input type="submit" class="button" value="Забронировать" ></input>
            </div>
        </form>
        
        <!-- <div class="blok">
            <?php
           $result = $conn->query('SELECT * FROM `booking`'); // запрос на выборку
           while($row = $result->fetch_assoc())// получаем все строки в цикле по одной
           {
               echo '<p> телефон '.$row['tel'].' дата '.$row['data'].'</p>';// выводим данные
           }
            ?>
        </div> -->
<?php 

 if (isset($_POST["phone"] , $_POST['data'])){
    // создание записи
    $sql = mysqli_query($conn, "INSERT INTO `booking` (`tel`,`data`) VALUES ('{$_POST['phone']}','{$_POST['data']}')");
    // сообщение, если дата не выбрана
    
    
    if ($sql) {
        echo '<label>
        <input type="checkbox" class="alertCheckbox" autocomplete="off" />
        <div class="alert success">
          <span class="alertClose">X</span>
          <span class="alertText">Успешно забронированно
          <br class="clear"/></span>
        </div>
      </label>';

    header("Refresh:5");
      } else {
        echo '<p>Произошла ошибка </p>';
      }  
   
}
 else{
        echo '<label>
        <input type="checkbox" class="alertCheckbox" autocomplete="off" />
        <div class="alert error">
          <span class="alertClose">X</span>
          <span class="alertText">Укажите дату
          <br class="clear"/></span>
        </div>
      </label>';
    }
 ?>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
  <script src="js/script.js">
    
  </script>
  <script src="js/build.js">
 </script>

</script>
</body>
</html> 


 
