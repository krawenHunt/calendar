// смена цвета по клику 
let booking = { calendar : document.querySelectorAll('.day__number')}

calendar.addEventListener("click", function(e)

{

  if_id = e . target. id;
// console.log(if_id)   
  the_class = e . target.className;


  if(the_class = "day__number")

  {

    if_id = document.getElementById(if_id);
// console.log(if_id)
    if(if_id .style . background == "gold" )

    {

      if_id .style . background = "#fff";

    }

    else

    {

      var links = document.querySelectorAll(".day__number");

      links.forEach(link => {

        link.setAttribute("style", "background:#fff");

      })

      if_id .style . background = "gold";

    }

  }


});
