
const dom = {
    calendar: document.getElementById('calendar')
  }
  const monthLength = [31,28,31,30,31,30,31,31,30,31,30,31]
  const monthNames = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь']
  const months = [
    {
        name: 'Январь',
        days: '31'
    },
    {
        name: 'Февраль',
        days: '28'
    },
    {
        name: 'Март',
        days: '31'
    },
    {
        name: 'Апрель',
        days: '30'
    },
    {
        name: 'Май',
        days: '31'
    },
    {
        name: 'Июнь',
        days: '30'
    },
    {
        name: 'Июль',
        days: '31'
    },
    {
        name: 'Август',
        days: '31'
    },
    {
        name: 'Сентябрь',
        days: '30'
    },
    {
        name: 'Октябрь',
        days: '31'
    },
    {
        name: 'Ноябрь',
        days: '30'
    },
    {
        name: 'Декабрь',
        days: '31'
    }
  ]
//   функция рендера календаря
  function renderMonth(monthNumber, year){
    const month = months[monthNumber]
    const monthHead = buildMonthTitle(month)
    const monthContent = [] 

    monthContent.push(buildMonthTitle(month.name))
    monthContent.push(['<div class="content" >'])
    monthContent.push(buildWeekDaysNames())
    monthContent.push(buildDates(year,monthNumber,month.days))
    monthContent.push('</div>')
    // console.log(buildDates(year,monthNumber,month.days))
    const monthBox = document.createElement('div')
    monthBox.className = 'month'
    monthBox.innerHTML = monthContent.join('')
    dom.calendar.appendChild(monthBox)
    
  }
//   рендер месяца
  for (let i = 0; i<12; i++){
    renderMonth(i, 2023)   

  }
//   рендер строки с названием месяца
  function buildMonthTitle(monthName){
    return `
        <div class="month__name">${monthName}<div class="line"></div></div> 
        `
  }

  
// создание блоков с днями неделями
  function buildWeekDaysNames(){
    const weekDay = ['пн','вт','ср','чт','пт','сб','вс']
    const daysNames = []
    for( let i = 0; i<7; i++){
        if(i>=5){
            // если выходные, окрашиваются в красный
            const dayNameTag = `<div class="month__date dweek month__date__weeknd" >${weekDay[i]}</div>`
            daysNames.push(dayNameTag)  
        }
        else{
            const dayNameTag = `<div class="month__date dweek " >${weekDay[i]}</div>`
            daysNames.push(dayNameTag)  
        }    
    
    }
    return daysNames.join('')
  }
//   создание блоков с датами
  function buildDates(year, month, daysCount){
   const date = new Date(year, month, 1) 
    const datesHTML= []
    const firstDay = date.getDay()
    let idx = 1
    let day = 1

   while(day <= daysCount){
    let dateHTML;
    if (idx<firstDay | firstDay == 0 && idx < 7){
        dateHTML = buildDate('',month+1)
        datesHTML.push(dateHTML)
        idx++
        
    }
    else{
        dateHTML = buildDate(day, month+1)
        
        datesHTML.push(dateHTML) 
        day++
        
    }
     
    
   
   }
   return datesHTML.join('')
  }

    // рендер строки с датами
  function buildDate(content, monthNumber){
    
    // каждой дате присваиваю id с днем и номером месяца  
   idx = 'id_'+ content + '_'+ monthNumber
//    console.log(idx)  
   
    return `
    <label for="${idx}" class="month__date dow" id="${content}_${monthNumber}" required>${content}</label>
    <input type="checkbox" name="data"  id="${idx}" value="2023.0${monthNumber}.${content}" readonly style="opacity:0; display:none" required></input>
    `   
}
